<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();

            $table->string('name');
            $table->string('email')->unique();

            $table->string('personal_mobile', 20);
            $table->string('personal_imei_1', 15);
            $table->string('personal_imei_2', 15);

            $table->string('offical_mobile', 20);
            $table->string('offical_imei_1', 15);
            $table->string('offical_imei_2', 15);

            $table->json('personal_mobile_app')->nullable();
            $table->json('Offical_mobile_app')->nullable();

            $table->string('personal_device_id');
            $table->string('offical_device_id');

            // Multiple roles (JSON)
            $table->json('roles')->nullable()->default('["employee"]');

            $table->json('customers')->nullable();

            $table->enum('status', ['active', 'inactive'])->default('active');

            // 🔹 Self reference (manager)
            $table->foreignId('manager_id')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();

            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('sessions');
    }
};
