<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tools_master', function (Blueprint $table) {
            $table->id();

            $table->string('customer_code', 50)->unique();

            // Auth
            $table->enum('authentication_type', ['basic', 'microsoft'])->nullable();
            $table->string('client_id')->nullable();
            $table->string('tenant_id')->nullable();
            $table->string('client_secret_id')->nullable();
            $table->text('client_secret_value')->nullable();
            $table->date('client_secret_expiry')->nullable();
            $table->string('redirect_url')->nullable();


            // DB
            $table->string('db_host');
            $table->string('db_name');
            $table->string('db_username');
            $table->string('db_password')->nullable();

            // SMTP
            $table->string('smtp_host')->nullable();
            $table->integer('smtp_port')->nullable();
            $table->string('smtp_admin_user')->nullable();
            $table->string('smtp_admin_pass')->nullable();
            $table->enum('smtp_auth', ['tls', 'ssl'])->default('ssl');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tools_master');
    }
};
