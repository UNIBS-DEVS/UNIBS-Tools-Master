<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('leaves', function (Blueprint $table) {
            $table->id();

            $table->enum('leave_type', [
                'Earned Leave',
                'Casual Leave',
                'Sick Leave'
            ]);

            $table->enum('duration', [
                'Full Day',
                'First Half',
                'Second Half'
            ]);

            $table->date('start_date');
            $table->date('end_date')->nullable();
            $table->text('remarks')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('leaves');
    }
};
