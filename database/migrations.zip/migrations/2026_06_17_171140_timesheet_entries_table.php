<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('timesheet_entries', function (Blueprint $table) {
            $table->id();

            $table->foreignId('timesheet_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->date('work_date');

            $table->foreignId('project_id')
                ->nullable()
                ->constrained()
                ->cascadeOnDelete();

            $table->foreignId('activity_id')
                ->nullable()
                ->constrained()
                ->cascadeOnDelete();

            $table->foreignId('sub_activity_id')
                ->nullable()
                ->constrained()
                ->cascadeOnDelete();

            $table->decimal('hours', 5, 2);

            $table->string('remarks')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('timesheet_entries');
    }
};
