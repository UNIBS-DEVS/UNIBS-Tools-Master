<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ats_clients_sys_config', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('client_id')->unique();

            // DB Config
            $table->string('db_host');
            $table->string('db_name');
            $table->string('db_username');
            $table->string('db_password')->nullable();

            // SMTP Config
            $table->string('smtp_host')->nullable();
            $table->string('smtp_port')->nullable();
            $table->string('smtp_admin_user')->nullable();
            $table->string('smtp_admin_pass')->nullable();
            $table->enum('smtp_auth', ['tls', 'ssl']);

            // IMAP Config
            $table->string('imap_host')->nullable();
            $table->string('imap_port')->nullable();
            $table->string('imap_encryption')->nullable();
            $table->string('imap_validate_cert')->nullable();
            $table->string('imap_protocol')->nullable();

            // Other SMTP
            $table->string('smtp_transport')->nullable();
            $table->string('smtp_driver')->nullable();

            // Client Info
            $table->string('client_name')->nullable();

            // Microsoft Graph
            $table->string('graph_client_id')->nullable();
            $table->string('graph_client_secret')->nullable();
            $table->string('graph_tenant_id')->nullable();
            $table->string('graph_from_email')->nullable();

            // Resume parsing
            $table->string('resume_parse_email')->nullable();
            $table->json('resume_parsing_time')->nullable();

            // Auth Type
            $table->enum('auth_type', ['google', 'microsoft'])->default('microsoft');

            $table->timestamps();

            // Foreign Key
            $table->foreign('client_id')
                ->references('id')
                ->on('ats_clients_master')
                ->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ats_clients_sys_config');
    }
};
