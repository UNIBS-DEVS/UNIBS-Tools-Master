<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('assets', function (Blueprint $table) {
            $table->id();
            $table->string('asset_category', 50);
            $table->string('asset_number', 100)->nullable();
            $table->string('serial_number', 150)->nullable();
            $table->string('brand_name', 100)->nullable();
            $table->string('model_number', 100)->nullable();
            $table->string('vendor', 100)->nullable();
            $table->enum('purchase_type', ['purchase', 'allocation'])->default('allocation');
            $table->integer('quantity')->default(1);
            $table->string('allocated_to', 150)->nullable();
            $table->date('allocation_date')->nullable();
            $table->string('asset_type', 50)->nullable();
            $table->string('type', 50);
            $table->string('sim_name', 20)->nullable();
            $table->string('sim_number', 15)->nullable();
            $table->string('item', 30)->nullable();
            $table->enum('status', ['Available', 'Allocated', 'Returned', 'Damaged'])->default('Allocated');
            $table->text('remarks')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('assets');
    }
};
